﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PIM.Models
{
    [Table("categoria")]
    public class Categoria
    {
        [Key]
        [Column("categoria_id")]
        public int CategoriaId { get; set; }

        [Required]
        [Column("nome_categoria")]
        public string NomeCategoria { get; set; }

        [Column("descricao")]
        public string Descricao { get; set; }

        public ICollection<BaseConhecimento> BaseConhecimentos { get; set; }
        public ICollection<Chamado> Chamados { get; set; }
    }

}
